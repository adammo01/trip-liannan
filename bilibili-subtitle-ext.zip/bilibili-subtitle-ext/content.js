// 内容脚本：拦截字幕网络请求
(function() {
  const originalFetch = window.fetch;
  const originalXHROpen = XMLHttpRequest.prototype.open;
  const originalXHRSend = XMLHttpRequest.prototype.send;

  let subtitleUrl = null;
  let subtitleData = null;
  let bvid = null;
  let title = null;

  // 获取当前视频信息
  function getVideoInfo() {
    bvid = window.__INITIAL_STATE__?.bvid || 
           document.querySelector('[data-vue-file]')?.__vue__?.bvid || 
           location.pathname.match(/BV\w+/)?.[0] || 'unknown';
    title = document.title.replace('_哔哩哔哩 (゜-゜)つロ 干杯~-bilibili', '').trim();
    return { bvid, title };
  }

  // 拦截fetch请求
  window.fetch = async function(url, ...args) {
    if (typeof url === 'string' && url.includes('aisubtitle.hdslb.com')) {
      subtitleUrl = url;
      try {
        const resp = await originalFetch.call(window, url, ...args);
        const clone = resp.clone();
        try {
          subtitleData = await clone.json();
          if (subtitleData && subtitleData.body && subtitleData.body.length > 0) {
            const info = getVideoInfo();
            chrome.runtime.sendMessage({
              type: 'SUBTITLE_CAPTURED',
              url: subtitleUrl,
              bvid: info.bvid,
              title: info.title,
              data: subtitleData
            });
          }
        } catch(e) {}
        return resp;
      } catch(e) {
        return originalFetch.call(window, url, ...args);
      }
    }
    return originalFetch.call(window, url, ...args);
  };

  // 拦截XHR请求
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    if (typeof url === 'string' && url.includes('aisubtitle.hdslb.com')) {
      subtitleUrl = url;
      this._interceptUrl = url;
    }
    return originalXHROpen.call(this, method, url, ...rest);
  };

  XMLHttpRequest.prototype.send = function(data, ...rest) {
    if (this._interceptUrl) {
      this.addEventListener('load', async function() {
        try {
          const data = JSON.parse(this.responseText);
          if (data && data.body && data.body.length > 0) {
            const info = getVideoInfo();
            chrome.runtime.sendMessage({
              type: 'SUBTITLE_CAPTURED',
              url: this._interceptUrl,
              bvid: info.bvid,
              title: info.title,
              data: data
            });
          }
        } catch(e) {}
      });
    }
    return originalXHRSend.call(this, data, ...rest);
  };

  // 监听WebSocket（备用方案）
  const origWS = window.WebSocket;
  window.WebSocket = function(url, ...args) {
    const ws = new origWS(url, ...args);
    if (typeof url === 'string' && url.includes('subtitle')) {
      const origOnMessage = ws.onmessage;
      ws.onmessage = async function(event) {
        try {
          const data = JSON.parse(event.data);
          if (data && data.body && data.body.length > 0) {
            const info = getVideoInfo();
            chrome.runtime.sendMessage({
              type: 'SUBTITLE_CAPTURED',
              url: url,
              bvid: info.bvid,
              title: info.title,
              data: data
            });
          }
        } catch(e) {}
        if (origOnMessage) origOnMessage.call(this, event);
      };
    }
    return ws;
  };

  // 定期检查字幕按钮
  setInterval(() => {
    const subtitleBtn = document.querySelector('.bilibili-player-subtitle-btn') ||
                        document.querySelector('[class*="subtitle"]') ||
                        document.querySelector('[class*="caption"]');
    if (subtitleBtn) {
      subtitleBtn.style.boxShadow = '0 0 8px #00ff88';
    }
  }, 2000);

})();
