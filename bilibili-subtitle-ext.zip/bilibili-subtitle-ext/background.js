// 后台脚本：存储捕获到的字幕
let capturedSubtitles = [];

chrome.runtime.onMessage.addListener((msg, sender, reply) => {
  if (msg.type === 'SUBTITLE_CAPTURED') {
    capturedSubtitles.push({
      url: msg.url,
      bvid: msg.bvid,
      title: msg.title,
      time: new Date().toISOString(),
      data: msg.data
    });
    chrome.action.setBadgeText({ text: String(capturedSubtitles.length), tabId: sender.tab.id });
    chrome.action.setBadgeBackgroundColor({ color: '#00ff88' });
    // 通知popup
    chrome.runtime.sendMessage({ type: 'UPDATE_LIST' });
  }
  if (msg.type === 'GET_SUBTITLES') {
    reply(capturedSubtitles);
  }
  if (msg.type === 'CLEAR') {
    capturedSubtitles = [];
    chrome.action.setBadgeText({ text: '' });
    reply('cleared');
  }
});
